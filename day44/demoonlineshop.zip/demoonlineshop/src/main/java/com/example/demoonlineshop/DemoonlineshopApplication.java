package com.example.demoonlineshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoonlineshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoonlineshopApplication.class, args);
	}

}
