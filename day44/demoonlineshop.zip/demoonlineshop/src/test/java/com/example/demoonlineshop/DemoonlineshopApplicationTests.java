package com.example.demoonlineshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoonlineshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
