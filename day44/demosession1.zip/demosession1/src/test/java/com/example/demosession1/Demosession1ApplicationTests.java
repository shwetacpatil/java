package com.example.demosession1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demosession1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
