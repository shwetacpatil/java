package com.example.demologin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemologinApplicationTests {

	@Test
	void contextLoads() {
	}

}
