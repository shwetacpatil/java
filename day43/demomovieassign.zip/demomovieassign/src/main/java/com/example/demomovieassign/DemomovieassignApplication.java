package com.example.demomovieassign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomovieassignApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomovieassignApplication.class, args);
	}

}
