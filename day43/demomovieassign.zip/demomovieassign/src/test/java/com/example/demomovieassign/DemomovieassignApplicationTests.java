package com.example.demomovieassign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomovieassignApplicationTests {

	@Test
	void contextLoads() {
	}

}
