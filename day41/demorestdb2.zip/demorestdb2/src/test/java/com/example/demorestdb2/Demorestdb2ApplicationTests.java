package com.example.demorestdb2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demorestdb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
