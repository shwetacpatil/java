package com.example.demomvc4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demomvc4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
