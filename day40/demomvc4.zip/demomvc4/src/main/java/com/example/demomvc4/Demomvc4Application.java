package com.example.demomvc4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demomvc4Application {

	public static void main(String[] args) {
		SpringApplication.run(Demomvc4Application.class, args);
	}

}
