package com.example.demomvcdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomvcdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
