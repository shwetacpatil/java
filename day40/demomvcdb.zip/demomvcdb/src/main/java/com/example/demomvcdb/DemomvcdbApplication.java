package com.example.demomvcdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomvcdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomvcdbApplication.class, args);
	}

}
