package com.example.OneToOnedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOnedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
