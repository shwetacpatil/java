package com.example.OneToOnedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToOnedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToOnedemoApplication.class, args);
	}

}
